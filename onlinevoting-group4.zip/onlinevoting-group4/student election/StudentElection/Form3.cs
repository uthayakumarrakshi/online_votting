﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentElection
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnyes_Click(object sender, EventArgs e)
        {
            MessageBox.Show("do you want do update","yes",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void btnno_Click(object sender, EventArgs e)
        {
            MessageBox.Show("do you want to go to back","ok",MessageBoxButtons.OKCancel,MessageBoxIcon.Question);
            Form11 form11 = new Form11();
            form11.Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
