﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace StudentElection
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            panel1.Visible = false;
        }

        private void btnok_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\student.mdf;Integrated Security=True");
            conn.Open();
            SqlCommand cmdd = new SqlCommand("insert into studenttable values (@StdId,@StdName,@StdYear,@StdFaculty,@StdGender)", conn);
            cmdd.Parameters.AddWithValue("@StdId", txtid.Text);
            cmdd.Parameters.AddWithValue("@StdName", txtname.Text);
            cmdd.Parameters.AddWithValue("@StdFaculty", txtfaculty.Text);
            cmdd.Parameters.AddWithValue("@StdYear", Convert.ToInt32(txtyear.Text));
            cmdd.Parameters.AddWithValue("@StdGender", txtgender.Text);
            cmdd.ExecuteNonQuery();

            MessageBox.Show("successfully insert");
            panel1.Visible = true;
            loaddata();
            conn.Close();
        }
          void loaddata()
        {

            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\student.mdf;Integrated Security=True");

            SqlCommand command = new SqlCommand("select * from studenttable", conn);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            data.DataSource = dt;
            adapter.Fill(dt);
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            loaddata();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\student.mdf;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("Update studenttable set StdName=@StdName  ,StdYear=@StdYear,StdFaculty=@StdFaculty ,StdGender=@StdGender", conn);
            cmd.Parameters.AddWithValue("@StdId", txtid.Text);
            cmd.Parameters.AddWithValue("@StdName", txtname.Text);
            cmd.Parameters.AddWithValue("@StdYear", Convert.ToInt32(txtyear.Text));
            cmd.Parameters.AddWithValue("@StdFaculty", txtfaculty.Text);
            cmd.Parameters.AddWithValue("@StdGender", txtgender.Text);
            cmd.ExecuteNonQuery();

            MessageBox.Show("successfully update");
            loaddata();
            conn.Close();
            txtid.Clear();
            txtfaculty.Clear();
            txtyear.Clear();
            txtname.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\student.mdf;Integrated Security=True");

            conn.Open();

            SqlCommand cmd = new SqlCommand("Delete studenttable where StdId=@StdId", conn);
            cmd.Parameters.AddWithValue("@stdId", txtid.Text);
            MessageBox.Show("do you want really delete this data", "Yes", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
            cmd.ExecuteNonQuery();
            MessageBox.Show("successfully Deleted", "ok", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            conn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form6 form6= new Form6();
            form6.Show();
            this.Hide();
        }
    }
}
