﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace StudentElection
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            panel1.Visible = false;
        }

        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            loaddata();

        }

        private void txtid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtid.Focus();
            }
        }

        private void txtname_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                txtname.Focus();
            }
        }

        private void txtyear_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode== Keys.Enter)
            {
                txtyear.Focus();
            }
        }

        private void txtfaculty_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
                {
                txtfaculty.Focus();
            }
        }

        private void txtgender_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            Form2 form2 = new Form2();
            this.Hide();
        }
        
        private void btninsert_Click(object sender, EventArgs e)
        {
            
                SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\candidate.mdf;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into candidatetable values (@CandidateId,@CandidateName,@CandidateYear,@CandidateFaculty,@CandidateGender)", con);
                cmd.Parameters.AddWithValue("@CandidateId", txtid.Text);
                cmd.Parameters.AddWithValue("@CandidateName", txtname.Text);
                cmd.Parameters.AddWithValue("@CandidateFaculty", txtfaculty.Text);
                cmd.Parameters.AddWithValue("@CandidateYear", Convert.ToInt32(txtyear.Text));
                cmd.Parameters.AddWithValue("@CandidateGender", txtgender.Text);

                cmd.ExecuteNonQuery();


                MessageBox.Show("successfully insert");
            panel1.Visible = true;
                loaddata();

                con.Close();
                txtid.Clear();
                txtfaculty.Clear();
                txtyear.Clear();
                txtname.Clear();
                txtgender.Clear();

           
        }
        void loaddata()
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\candidate.mdf;Integrated Security=True");

            SqlCommand command = new SqlCommand("select * from candidatetable", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            data.DataSource = dt;
            adapter.Fill(dt);
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\candidate.mdf;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update candidateTable set CandidateName=@CandidateName  ,CandidateYear=@CandidateYear,CandidateFaculty=@CandidateFaculty ,CandidateGender=@CandidateGender", con);
            cmd.Parameters.AddWithValue("@CandidateId", txtid.Text);
            cmd.Parameters.AddWithValue("@CandidateName", txtname.Text);
            cmd.Parameters.AddWithValue("@CandidateYear", Convert.ToInt32(txtyear.Text));
            cmd.Parameters.AddWithValue("@CandidateFaculty", txtfaculty.Text);
            cmd.Parameters.AddWithValue("@CandidateGender", txtgender.Text);
            cmd.ExecuteNonQuery();

            MessageBox.Show("successfully update");
            loaddata();
            con.Close();
            txtid.Clear();
            txtfaculty.Clear();
            txtyear.Clear();
            txtname.Clear();
            
           
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\candidate.mdf;Integrated Security=True");
            con.Open();

            SqlCommand cmd = new SqlCommand("Delete candidatetable where CandidateId=@CandidateId", con);
            cmd.Parameters.AddWithValue("@CandidateId", txtid.Text);
            MessageBox.Show("do you want really delete this data", "Yes", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
            cmd.ExecuteNonQuery();
            MessageBox.Show("successfully Deleted", "ok", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
        }

        private void btndelet_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\candidate.mdf;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from candidatetable", con);
            SqlDataAdapter da=new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            data.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string id;
            loaddata();
           
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "upload the image";
            ofd.Filter = "JPG Files|* Jpg|JPEG Files |* Jpeg|PNG Files|* Png|All Files|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox.Image = new Bitmap(ofd.FileName);
                loaddata();
            }
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox_Click_1(object sender, EventArgs e)
        {

        }
    }
}
