﻿namespace StudentElection
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtfaculty = new System.Windows.Forms.TextBox();
            this.btnvote = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gabriola", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(138, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(446, 74);
            this.label1.TabIndex = 0;
            this.label1.Text = "Good to see you in vooting page";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(51, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "CandidateId";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(51, 253);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = "CandidateFaculty";
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(330, 137);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(202, 22);
            this.txtid.TabIndex = 3;
            // 
            // txtfaculty
            // 
            this.txtfaculty.Location = new System.Drawing.Point(330, 253);
            this.txtfaculty.Name = "txtfaculty";
            this.txtfaculty.Size = new System.Drawing.Size(202, 22);
            this.txtfaculty.TabIndex = 4;
            // 
            // btnvote
            // 
            this.btnvote.BackColor = System.Drawing.Color.Blue;
            this.btnvote.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvote.Location = new System.Drawing.Point(715, 346);
            this.btnvote.Name = "btnvote";
            this.btnvote.Size = new System.Drawing.Size(170, 64);
            this.btnvote.TabIndex = 5;
            this.btnvote.Text = "Vote";
            this.btnvote.UseVisualStyleBackColor = false;
            this.btnvote.Click += new System.EventHandler(this.btnvote_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::StudentElection.Properties.Resources.images1;
            this.pictureBox1.Location = new System.Drawing.Point(700, 59);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(225, 222);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1051, 479);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnvote);
            this.Controls.Add(this.txtfaculty);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Votting";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtfaculty;
        private System.Windows.Forms.Button btnvote;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}