﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace StudentElection
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\student.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("Select * from studenttable  Where StdId=@StdId and StdName=@StdName", con);
            cmd.Parameters.AddWithValue("@stdId",txtid.Text);
            cmd.Parameters.AddWithValue("@stdName", txtname.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                this.Hide();
                MessageBox.Show("you can log in","ok",MessageBoxButtons.OKCancel,MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("you can not log in","error",MessageBoxButtons.OKCancel,MessageBoxIcon.Error);
            }
            Form6 form6=new Form6();
            form6.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
