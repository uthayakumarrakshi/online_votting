﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentElection
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
            panel1.Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Form2 form2 = new Form2();
            
        }
        void loaddata()
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\candidate.mdf;Integrated Security=True");

            SqlCommand command = new SqlCommand("select * from candidatetable", con);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            dataGridView1.DataSource = dt;
            adapter.Fill(dt);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            Form2 form2 = new Form2();
            loaddata();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}
