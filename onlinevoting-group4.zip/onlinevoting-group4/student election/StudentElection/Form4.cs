﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace StudentElection
{
    public partial class Form4 : Form
    {
        public string CandidateId,name,faculty;
        private Form2 form2Var;
        public Form4()
        {
            InitializeComponent();
        }

        private void btnvote_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\StudentElection\\StudentElection\\candidate.mdf;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("Select * from candidatetable  Where CandidateId=@CandidateId and CandidateFaculty=@CandidateFaculty", con);
            cmd.Parameters.AddWithValue("@CandidateId", txtid.Text);
            cmd.Parameters.AddWithValue("@CandidateFaculty", txtfaculty.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                this.Hide();
                MessageBox.Show("u can vote", "ok", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("u can not  vote", "error", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
            Form8 form8= new Form8();
            form8.Show();
            this.Hide();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
          
        }
        public void setForm2(Form2 form2)
        {
            
        }
    }
}
