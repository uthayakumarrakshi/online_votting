﻿namespace StudentElection
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Title = new System.Windows.Forms.Label();
            this.btnstd = new System.Windows.Forms.Label();
            this.btncan = new System.Windows.Forms.Button();
            this.btnstu = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.BackColor = System.Drawing.Color.Turquoise;
            this.Title.Font = new System.Drawing.Font("MV Boli", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.Color.Crimson;
            this.Title.Location = new System.Drawing.Point(297, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(794, 37);
            this.Title.TabIndex = 0;
            this.Title.Text = "WELCOME TO THE UNIVERCITY OF VAVUNIYA PAGE";
            // 
            // btnstd
            // 
            this.btnstd.AutoSize = true;
            this.btnstd.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstd.Location = new System.Drawing.Point(158, 198);
            this.btnstd.Name = "btnstd";
            this.btnstd.Size = new System.Drawing.Size(186, 26);
            this.btnstd.TabIndex = 1;
            this.btnstd.Text = "Select your option";
            // 
            // btncan
            // 
            this.btncan.BackColor = System.Drawing.Color.RoyalBlue;
            this.btncan.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncan.Location = new System.Drawing.Point(467, 108);
            this.btncan.Name = "btncan";
            this.btncan.Size = new System.Drawing.Size(118, 42);
            this.btncan.TabIndex = 2;
            this.btncan.Text = "Candidate";
            this.btncan.UseVisualStyleBackColor = false;
            this.btncan.Click += new System.EventHandler(this.btncan_Click);
            // 
            // btnstu
            // 
            this.btnstu.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnstu.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstu.Location = new System.Drawing.Point(467, 313);
            this.btnstu.Name = "btnstu";
            this.btnstu.Size = new System.Drawing.Size(118, 42);
            this.btnstu.TabIndex = 3;
            this.btnstu.Text = "Student";
            this.btnstu.UseVisualStyleBackColor = false;
            this.btnstu.Click += new System.EventHandler(this.btnstu_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 30;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::StudentElection.Properties.Resources.option;
            this.pictureBox1.Location = new System.Drawing.Point(786, 137);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(318, 194);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1198, 511);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnstu);
            this.Controls.Add(this.btncan);
            this.Controls.Add(this.btnstd);
            this.Controls.Add(this.Title);
            this.Name = "Form1";
            this.Text = "Option";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label btnstd;
        private System.Windows.Forms.Button btncan;
        private System.Windows.Forms.Button btnstu;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

